package TestFeatureClass;
use Moose;

extends 'CatalystX::Features::Feature';

1;

