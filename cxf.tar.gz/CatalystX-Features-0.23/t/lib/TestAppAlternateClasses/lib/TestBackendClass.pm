package TestBackendClass;
use Moose;

extends 'CatalystX::Features::Backend';

1;
