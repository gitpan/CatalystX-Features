package TestBackendClass;

use base 'CatalystX::Features::BackendClass';

1;
